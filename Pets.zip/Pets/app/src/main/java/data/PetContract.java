package data;

import android.provider.BaseColumns;

public final class PetContract {
    private PetContract(){}

    public static class PetEntry implements BaseColumns {

        public static final String TABLE_NAME = "pet";

        public static final String _ID = BaseColumns._ID;
        public static final String COLUMN_PET_NAME = "_name";
        public static final String COLUMN_PET_BREED = "breed";
        public static final String COLUMN_PET_GENDER = "gender";
        public static final String COLUMN_PET_WEIGHT = "weight";

        public static final int GENDER_MALE = 1;
        public static final int GENDER_FEMALE = 2;
        public static final int GENDER_UNKNOWN = 0;

        public static final String CREATE_SQL_ENTRIES = "CREATE TABLE " +  PetEntry.TABLE_NAME + " ("+ PetEntry._ID
                + PetEntry.COLUMN_PET_NAME +
                PetEntry.COLUMN_PET_BREED +
                PetEntry.COLUMN_PET_GENDER +
                PetEntry.COLUMN_PET_WEIGHT +");";

        public static final String DELETE_SQL_ENTRIES = "DROP TABLE IF EXISTS " +PetEntry.TABLE_NAME;


    }

}
